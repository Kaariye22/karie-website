# KARIE Website
Full-stack personal/social website for Khadar Abdi Kariye.

## Stack
- Python 3.12 + Django
- SQLite for development (switch to PostgreSQL for production)
- HTML/CSS/JavaScript
- Optional PHP bridge under `php/` for shared-hosting/contact integration
- Django admin for publishing posts/videos and managing users/messages

## Run on Android/Termux or PC
```bash
python -m venv venv
source venv/bin/activate
pip install -r requirements.txt
python manage.py migrate
python manage.py createsuperuser
python manage.py runserver
```
Open http://127.0.0.1:8000/

Admin: http://127.0.0.1:8000/admin/

## Social accounts
TikTok: @karie99
Facebook: Khadar Abdi Kariye
WhatsApp: 0915767870
Email: kaariyebusiness@gmail.com

## Important
Automatic importing of Facebook/TikTok posts requires each platform's official API/OAuth permissions and credentials. This project includes the database fields and UI for social links, plus an admin-managed feed. It does not bypass platform restrictions.
