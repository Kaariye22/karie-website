<?php
// Optional PHP bridge for hosts that support PHP.
// The main application is Django. This endpoint validates contact input
// and can be adapted to forward messages to your mail service.
header('Content-Type: application/json');
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { http_response_code(405); echo json_encode(['error'=>'POST required']); exit; }
$name = trim($_POST['name'] ?? '');
$email = trim($_POST['email'] ?? '');
$message = trim($_POST['message'] ?? '');
if (!$name || !filter_var($email, FILTER_VALIDATE_EMAIL) || !$message) {
  http_response_code(422); echo json_encode(['error'=>'Invalid form data']); exit;
}
echo json_encode(['ok'=>true,'message'=>'Validated. Connect this endpoint to your mail service.']);
?>