from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from .models import Post, SocialLink, ContactMessage, ChatMessage

def home(request):
    return render(request, "home.html", {
        "posts": Post.objects.filter(published=True),
        "socials": SocialLink.objects.filter(active=True),
    })

def about(request):
    return render(request, "about.html")

def contact(request):
    if request.method == "POST":
        ContactMessage.objects.create(
            name=request.POST.get("name",""),
            email=request.POST.get("email",""),
            message=request.POST.get("message",""),
        )
        return render(request, "contact.html", {"sent": True})
    return render(request, "contact.html")

@login_required
def chat(request):
    users = User.objects.exclude(id=request.user.id)
    selected = request.GET.get("user")
    messages = []
    other = None
    if selected:
        try:
            other = User.objects.get(id=selected)
            messages = ChatMessage.objects.filter(
                sender__in=[request.user, other],
                receiver__in=[request.user, other]
            )
        except User.DoesNotExist:
            pass
    if request.method == "POST" and other:
        body = request.POST.get("body","").strip()
        if body:
            ChatMessage.objects.create(sender=request.user, receiver=other, body=body)
        return redirect(f"/chat/?user={other.id}")
    return render(request, "chat.html", {"users":users,"messages":messages,"other":other})

def login_view(request):
    if request.method == "POST":
        u = authenticate(request, username=request.POST.get("username"), password=request.POST.get("password"))
        if u:
            login(request,u)
            return redirect("/")
        return render(request,"login.html",{"error":"Username or password is incorrect."})
    return render(request,"login.html")

def logout_view(request):
    logout(request)
    return redirect("/")
