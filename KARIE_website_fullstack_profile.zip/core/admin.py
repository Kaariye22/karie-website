from django.contrib import admin
from .models import Post, SocialLink, ContactMessage, ChatMessage
admin.site.register(Post)
admin.site.register(SocialLink)
admin.site.register(ContactMessage)
admin.site.register(ChatMessage)
